# Obsidian과 MCP 실습 연결 안내

모든 노트는 가상 자료입니다. 수업에서는 이 폴더의 `지식보관함`만 사용합니다.
개인 보관함, 실제 회원 자료, 회사의 Notion·Confluence 공간은 연결하지 않습니다.

## 준비와 진행

- 교육 전에 Node.js LTS와 Obsidian을 설치할 수 있는지 확인합니다. 다운로드: https://nodejs.org/ · https://obsidian.md/download
- Claude Code 또는 Codex 중 본인 도구 하나를 준비하면 됩니다. 둘 다 연결할 필요는 없습니다.
- Obsidian의 보관함 관리에서 **폴더를 보관함으로 열기(Open folder as vault)**를 선택해 `지식보관함`를 엽니다. 커뮤니티 플러그인과 Sync 가입은 필요하지 않습니다.
- P09-A 또는 P09-B로 MCP를 준비하고, 새 대화/확장 재시작 후 P09-C로 연결을 확인합니다.
- P10으로 확정 내용을 찾고 P11로 새 공지 노트를 만듭니다. Obsidian에서 새 노트를 열어 원문과 비교합니다.
- 설치가 막히면 강사 화면으로 같은 조회·저장 과정을 확인합니다. 일반 파일 읽기로 대신한 경우에는 MCP 실습 성공으로 기록하지 않습니다.

## 어떤 서버를 연결하나요

MCP 프로젝트의 공식 참고 구현인 `@modelcontextprotocol/server-filesystem@1.0.0`를 로컬 프로세스로 실행합니다.
Obsidian 전용 공식 서버가 아니라 보관함의 Markdown 파일을 읽고 쓰는 **filesystem MCP 서버**입니다.
실습 서버 이름은 `hansalim-notes`입니다. 별도 API 키나 Obsidian 플러그인은 사용하지 않습니다.
서버가 로컬에서 실행돼도 읽은 노트 내용은 사용하는 클라우드 AI에 전달될 수 있습니다.

## AI에게 설치를 맡길 때의 작업 범위

1. 현재 프로젝트와 `지식보관함`가 있는지 확인하고 보관함 절대 경로를 구합니다.
2. Node.js와 npx 실행 여부를 확인합니다. 없으면 설치 안내까지만 하고 사람이 설치 후 다시 시작합니다.
3. 기존 설정을 보존하며 서버 항목 하나만 추가합니다. 같은 이름의 설정이 다르면 차이를 먼저 알립니다.
4. Windows 네이티브는 `cmd /c npx`, macOS/Linux/WSL은 `npx`를 사용합니다. WSL이면 경로도 WSL에서 유효한 경로로 바꿉니다.
5. Claude Code는 프로젝트 `.mcp.json`의 `mcpServers` 아래에 추가합니다. VS Code의 Copilot용 `.vscode/mcp.json`과 다릅니다.
6. Codex는 신뢰한 프로젝트의 `.codex/config.toml`에 추가합니다. 지원하지 않는 구버전이면 업데이트 방법이나 MCP 설정 화면을 안내합니다. 사용자 전체 설정으로 몰래 옮기지 않습니다.
7. Claude Code는 프로젝트 MCP 승인과 `/mcp` 상태를 확인합니다. Codex 확장은 MCP servers에서 저장 후 Restart extension을 하거나 확장을 다시 엽니다.
8. **설정 파일 존재와 연결 성공을 구분**합니다. 새 세션에서 실제 MCP 도구를 호출해야 합니다.

## Windows 설정 예시

아래의 절대 경로는 예시입니다. 학생 PC에서 확인한 실제 경로로 바꿉니다.

Claude Code `.mcp.json`:
```json
{
  "mcpServers": {
    "hansalim-notes": {
      "command": "cmd",
      "args": ["/c", "npx", "-y", "@modelcontextprotocol/server-filesystem@1.0.0", "C:/Users/사용자/Desktop/한살림_AI실습/지식보관함"]
    }
  }
}
```

Codex 프로젝트 `.codex/config.toml`:
```toml
[mcp_servers.hansalim-notes]
command = "cmd"
args = ["/c", "npx", "-y", "@modelcontextprotocol/server-filesystem@1.0.0", "C:/Users/사용자/Desktop/한살림_AI실습/지식보관함"]
startup_timeout_sec = 60
enabled_tools = ["list_allowed_directories", "list_directory", "search_files", "read_text_file", "read_multiple_files", "write_file"]
```

macOS/Linux/WSL에서는 command를 `npx`로, args를 `["-y", "@modelcontextprotocol/server-filesystem@1.0.0", "확인한 보관함 절대 경로"]`로 바꿉니다.
MCP 허용 경로는 실행 인수뿐 아니라 클라이언트의 Roots 설정으로 바뀔 수 있습니다.
P09-C의 `list_allowed_directories` 반환값이 보관함 한 곳인지 확인합니다. 넓어졌으면 자료를 읽기 전에 설정을 수정합니다.
이 서버는 쓰기도 지원합니다. “먼저 읽기만”은 작업 지시이며 읽기 전용 권한을 설정한 것과 같지 않습니다.
허용 경로는 이 MCP 서버의 범위입니다. 에이전트의 다른 파일·셸 도구 권한까지 제한하지는 않습니다.

## 성공 확인과 종료

- P09-C: 실제 서버·도구 이름, 허용 경로, 파일 목록을 확인합니다.
- P10: 근거 파일 이름과 문서 날짜가 붙은 답을 원문과 비교합니다.
- P11: `결과노트/행사안내_초안.md`를 MCP로 저장한 뒤 다시 읽어 대조합니다. 중복 이름이면 새 번호를 붙입니다.
- Obsidian에서 결과노트를 열어 근거 링크를 눌러 봅니다. 결과노트에서 행사·업무규칙 노트로 가는 링크는 `../행사/...md`, `../업무규칙/...md` 같은 실제 상대 경로를 사용합니다.
- 끝나면 P12로 이 연습 연결만 끕니다. 다른 서버와 만든 노트는 보존합니다.

## Notion과 Confluence로 확장

문서 찾기, 근거 확인, 새 초안 저장이라는 작업 순서는 같습니다. 연결 방법과 권한은 다릅니다.
Notion은 공식 원격 MCP `https://mcp.notion.com/mcp`, Confluence는 Atlassian Rovo MCP `https://mcp.atlassian.com/v2/mcp`를 사용합니다.
OAuth 로그인은 본인이 진행합니다. 연결한 사용자에게 허용된 자료와 조직 정책에 따라 도구가 동작합니다.
연습 공간만 쓰라는 프롬프트는 접근 권한 자체를 줄이지 않습니다. 실제 권한과 도구 범위를 먼저 확인합니다.
P13은 수업 뒤 조직이 허용한 가상 연습 공간에서 사용하는 연결 준비 요청문입니다.
수업 중에는 개인 또는 회사 클라우드 계정 연결·게시를 요구하지 않습니다.

## 공식 안내 (2026-10-18 확인)

- https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem
- https://obsidian.md/help/Files%2Band%2Bfolders/Manage%2Bvaults
- https://code.claude.com/docs/en/mcp
- https://learn.chatgpt.com/docs/extend/mcp?surface=cli
- https://developers.notion.com/guides/mcp/overview
- https://developer.atlassian.com/cloud/rovo-mcp/
